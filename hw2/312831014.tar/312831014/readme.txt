1. make
2. Floorplan input.in output.dat