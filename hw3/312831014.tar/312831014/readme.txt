make
./Lab3 [input file name] [output file name]